﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=TW1T4Y\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
