﻿namespace TeisterMask.DataProcessor
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Text;
    using System.Xml.Serialization;
    using Data;
    using Newtonsoft.Json;
    using TeisterMask.Data.Models.Enums;
    using TeisterMask.DataProcessor.ExportDto;
    using Formatting = Newtonsoft.Json.Formatting;

    public class Serializer
    {
        public static string ExportProjectWithTheirTasks(TeisterMaskContext context)
        {
            StringBuilder sb = new StringBuilder();

            var projects = context.Projects
                .Where(p => p.Tasks.Count >= 1)
                .ToList()
                .Select(p => new ExportProjectDto
                {
                    TasksCount = p.Tasks.Count,
                    ProjectName = p.Name,
                    HasEndDate = p.DueDate == null ? "No" : "Yes",
                    Tasks = p.Tasks.Select(t => new ExportTaskDto
                    {
                        Name = t.Name,
                        Label = t.LabelType.ToString()
                    })
                    .OrderBy(t => t.Name)
                    .ToList()
                })
                .OrderByDescending(p => p.TasksCount)
                .ThenBy(p => p.ProjectName)
                .ToList();

            var xmlSerializer = new XmlSerializer(typeof(List<ExportProjectDto>), new XmlRootAttribute("Projects"));
            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            xmlSerializer.Serialize(new StringWriter(sb), projects, namespaces);

            return sb.ToString().TrimEnd();
        }

        public static string ExportMostBusiestEmployees(TeisterMaskContext context, DateTime date)
        {
            var busiestEmployees = context.Employees
                                  .ToList() // Need for judge
                                  .Where(t => t.EmployeesTasks.Any(x => x.Task.OpenDate >= date))
                                  .Select(t => new
                                  {
                                      Username = t.Username,
                                      Tasks = t.EmployeesTasks
                                              .Where(s => s.Task.OpenDate >= date)
                                              .Select(x => new
                                              {
                                                  TaskName = x.Task.Name,
                                                  OpenDate = x.Task.OpenDate.ToString("d", CultureInfo.InvariantCulture),
                                                  DueDate = x.Task.DueDate.ToString("d", CultureInfo.InvariantCulture),
                                                  LabelType = Enum.GetName(typeof(LabelType), x.Task.LabelType),
                                                  ExecutionType =
                                                 Enum.GetName(typeof(ExecutionType), x.Task.ExecutionType)

                                              })
                                              .OrderByDescending(d => DateTime.ParseExact(d.DueDate, "d", CultureInfo.InvariantCulture))
                                              .ThenBy(n => n.TaskName)
                                              .ToList()
                                  })
                                  .OrderByDescending(t => t.Tasks.Count)
                                  .ThenBy(u => u.Username)
                                  .Take(10)
                                  .ToList();

            var busiestEmployeesJSON = JsonConvert.SerializeObject(busiestEmployees, Formatting.Indented);

            return busiestEmployeesJSON;

            /*

            var employees = context
                .Employees
                .Where(x => x.EmployeesTasks.Any())
                .Select(x => new
                {
                    Username = x.Username,
                    Task = x.EmployeesTasks
                            .Where(j => j.Task.OpenDate >= date)
                            .Select(t => new
                            {
                                TaskName = t.Task.Name,
                                OpenDate = t.Task.OpenDate.ToString("d"),
                                DueDate = t.Task.DueDate.ToString("d"),
                                LabelType = t.Task.LabelType.ToString(),
                                ExecutionType = t.Task.ExecutionType.ToString()
                            })
                            .OrderByDescending(d => d.DueDate)
                            .ThenBy(tn => tn.TaskName)
                            .ToList()
                })
                .OrderByDescending(n => n.Task.Count())
                .ThenBy(un => un.Username)
                .Take(10)
                .ToList();

            var res = JsonConvert.SerializeObject(employees, Formatting.Indented);

            return res;
            */
        }
    }
}