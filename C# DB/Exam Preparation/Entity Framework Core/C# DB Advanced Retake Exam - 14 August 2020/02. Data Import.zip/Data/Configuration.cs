﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=TW1T4Y\SQLEXPRESS;Database=SoftJail;Trusted_Connection=True";
    }
}
