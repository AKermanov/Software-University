﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=TW1T4Y\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
