﻿namespace P01_HospitalDatabase.Data.Config
{
   public class Connection
    {
        public static string ConnectionString = @"Server=TW1T4Y\SQLEXPRESS;Database=HospitalDatabase;Integrated Security=true;";
    }
}
