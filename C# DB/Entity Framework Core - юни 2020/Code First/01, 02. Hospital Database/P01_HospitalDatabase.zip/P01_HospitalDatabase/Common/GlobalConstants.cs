﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Common
{
   public static class GlobalConstants
    {
        public const int CandAMaxLenght = 250;
        public const int PeoplesNameMaxLenght = 100;
        public const int EmailMaxLenght = 80;
        public const int NamesMaxLenght = 50;
    }
}
