﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp31
{
    public enum HeroEnum
    {
        Druid = 1,
        Paladin = 2,
        Rogue = 3,
        Warrior = 4
    }
}
