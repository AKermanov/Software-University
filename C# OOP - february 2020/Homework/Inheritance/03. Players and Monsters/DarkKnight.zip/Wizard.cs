﻿namespace PlayersAndMonsters
{
   public class Wizard:Hero
    {
        public Wizard(string name, int level)
         : base(name, level)
        {

        }
    }
}
