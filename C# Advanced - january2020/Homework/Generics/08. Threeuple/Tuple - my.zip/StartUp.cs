﻿using System;
using System.Linq;

namespace Tuple
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            var name = Console.ReadLine().Split();
            var firstLastName = name[0] + " " + name[1];
            var torwn = name[2];
            var firsItaration = new Tuple<string>(firstLastName, torwn);
            Console.WriteLine(firsItaration);

            var nameLiterBears = Console.ReadLine().Split();
            var firstName = nameLiterBears[0];
            var literBears = nameLiterBears[1];
            var beer = new Tuple<string>(firstName, literBears);
            Console.WriteLine(beer);

            var digits = Console.ReadLine()
                .Split()
                .Select(double.Parse)
                .ToArray();
            var integ = digits[0];
            var doubleTwo = digits[1];
            var result = new Tuple<double>(integ, doubleTwo);
            Console.WriteLine(result);
        }
    }
}
