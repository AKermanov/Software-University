﻿using System;

namespace ConsoleApp90
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                string input = Console.ReadLine();
                Box<string> box = new Box<string>(input);

                Console.WriteLine(box.ToString());
            }
            

        }
    }
}
